
//Ziqi Wang 10.30
#include <iostream>
#include "Circles.h"
#include "Triangles.h"
#include "spheres.h"
#include "RegularTetrahedron.h"
using namespace std;
//I use virtual function to void calling wrong function in child class
/*in Two/Three dimensional shape, I define the center point as protected type, because every shape needs a center*/
int main()
{
   int i=0;
    do
   {
       cout<<"\nPlease choose a shape or 0 to exit: \n"<<"1.Circle\n"
           <<"2.Triangle\n"<<"3.Sphere\n"<<"4.Regular Tetrahedron\n"<<"0.Exit"<<endl;
       cin>>i;
       cout<<"Choice"<<i<<endl;
       switch(i)
       {
           case 1:
           {
               Circle Circle_1;
               Circle_1.setCenter();
               Circle_1.setRadius();
               Circle_1.getCenter();
               Circle_1.getArea();
               break;
           }
           case 2:
           {

               Triangle Triangle_1;
               Triangle_1.setCenter();
               Triangle_1.setSideLength();
               Triangle_1.getCenter();
               Triangle_1.getArea();
               break;
           }
           case 3:
           {
               Sphere Sphere_1;
               Sphere_1.setCenter();
               Sphere_1.setRadius();
               Sphere_1.getCenter();
               Sphere_1.getArea();
               Sphere_1.getVolume();
               break;
           }

           case 4:
           {
               RegularTetrahedron RegularTetrahedron_1;
               RegularTetrahedron_1.setCenter();
               RegularTetrahedron_1.setSideLength();
               RegularTetrahedron_1.getCenter();
               RegularTetrahedron_1.getArea();
               RegularTetrahedron_1.getVolume();
               break;
           }


           case 0:
               cout<<"Thanks for using!"<<endl;//empty the output register.
               break;
           default :
               cout<<"This choice is not available!"<<endl;




       }
   }while(i>0);

    return 0;
}