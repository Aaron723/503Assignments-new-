//Ziqi Wang 10.30

#ifndef HOMEWORK8_SHAPES_H
#define HOMEWORK8_SHAPES_H
class shape//the original type
{
public:
    virtual void setCenter()=0;
    virtual void getCenter()=0;
};
#endif //HOMEWORK8_SHAPES_H
